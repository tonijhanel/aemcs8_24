"use script"
use( function(){
    /* get container styles */
    var  bgcolor = granite.resource.properties["bgcolor"];
    var ctborderstyle = granite.resource.properties["ctborderstyle"];
    var containerstyle = "test";
    var bdrradius = granite.resource.properties["bdrradius"];
    var ctbordersize = granite.resource.properties["ctbordersize"];
    var bgimage =  granite.resource.properties["fileReference"];
    var containerstyle = "background-color: " + bgcolor +"; border: " + ctborderstyle + " " + ctbordersize + " ;"  ; 
	var bordercolor = granite.resource.properties["bordercolor"];
    var stretch  = granite.resource.properties["stretch"];
    
    /* get content-overlay styles */
    var contentbg = granite.resource.properties["contentbg"];
    var contentbrdstyle = granite.resource.properties["borderstyle"]; 
    var contentbrdsize = granite.resource.properties["bordersize"]; 
    var contentradius = granite.resource.properties["radius"]; 
    var contentbrdcolor = granite.resource.properties["cntbdrcolor"]; 
    
    /* get text styles */
    var pretitlecolor = granite.resource.properties["pretitlecolor"]; 
    var pretitlefontsize = granite.resource.properties["pretitlefontsize"]; 
	var titlecolor = granite.resource.properties["titlecolor"]; 
    var titlefontsize = granite.resource.properties["titlefontsize"];
    var descolor = granite.resource.properties["descolor"];
  	var descfontsize = granite.resource.properties["descfontsize"];
    
	
    /* get button styles */
    
    var btnbgcolor = granite.resource.properties["btnbgcolor"];
    var btntxtcolor = granite.resource.properties["btntxtcolor"];
   
    /* get image styles */
    var imgradius =  granite.resource.properties["imgbdrradius"];

    
    /* define image styles */
    var imagestyle = "";
    if(imgradius != null) {
    	imagestyle = imagestyle.concat("border-radius: ", imgradius, "; ");
    }
    /* defenine container styles */
    var containerstyle = "";
     
    if(bgcolor != null) {
    	containerstyle = containerstyle.concat("background-color: ", bgcolor, "; ");
    }
    if(ctborderstyle != null) {
    	containerstyle = containerstyle.concat("border-style: ", ctborderstyle, "; ");
    }
    if(ctbordersize != null) {
    	containerstyle = containerstyle.concat("border-width: ", ctbordersize, "; ");
    }
    if(bdrradius != null) {
    	containerstyle = containerstyle.concat("border-radius: ", bdrradius, "; ");
    }
    if(bordercolor != null) {
    	containerstyle = containerstyle.concat("border-color: ", bordercolor, "; ");
    }
    if(stretch == "true") {
    	stretch = "height: 100%; ";
    }
    
     
    /* define content styles */
	var contentstyle = "";
	if (contentbg != null) {
       contentstyle = "background-color: ".concat(contentbg, "; ");
    }
    if(contentbrdstyle != null) {
    	contentstyle = contentstyle.concat("border-style: ", contentbrdstyle, "; ");
    }
    if(contentbrdsize != null) {
    	contentstyle = contentstyle.concat("border-width: ", contentbrdsize, "; ");
    }
    if(contentradius != null) {
    	contentstyle = contentstyle.concat("border-radius: ", contentradius, "; ");
    }
    if(contentbrdcolor != null) {
    	contentstyle = contentstyle.concat("border-color: ", contentbrdcolor, "; ");
    }
    
 
    
    
    
    /* define pretitle style */
    var pretitlestyle = "";
     if (pretitlefontsize != null) {
       pretitlestyle = "font-size: ".concat(pretitlefontsize, "; ");
    }
    if(pretitlecolor != null) {
    	pretitlestyle = pretitlestyle.concat("color: ", pretitlecolor, ";");
    }
    
    
      
    /* define title style */
    var titlestyle = "";
     if (pretitlefontsize != null) {
       titlestyle = "font-size: ".concat(titlefontsize, "; ");
    }
    if(pretitlecolor != null) {
    	titlestyle = titlestyle.concat("color: ", titlecolor, ";");
    }
    
    
    /* define desc style */
    var descstyle = "";
     if (pretitlefontsize != null) {
       descstyle = "font-size: ".concat(descfontsize, "; ");
    }
    if(pretitlecolor != null) {
    	descstyle = descstyle.concat("color: ", descolor, ";");
    }
    
    
    /* define button style */
    var buttonstyle = "";
    if (btnbgcolor != null) {
       buttonstyle = "background-color:".concat(btnbgcolor, "; ");
    }
    if(btntxtcolor != null) {
    	buttonstyle = buttonstyle.concat("color: ", btntxtcolor, ";");
    }

   
    return{
    	bgcolor:bgcolor,
        containerstyle: containerstyle,
        ctborderstyle: ctborderstyle,
        bdrradius:  bdrradius,
        ctbordersize: ctbordersize,
        bgimage: bgimage,
        contentstyle: contentstyle,
        pretitlestyle: pretitlestyle,
        titlestyle: titlestyle,
        descstyle: descstyle,
        buttonstyle: buttonstyle,
        stretch: stretch,
        imagestyle: imagestyle
    };
});